# Accuknox eBPF Assignment

## Features
- XDP based TCP port filtering
- Userspace configurable port using BPF maps
- Process-aware filtering using cgroup hooks
- Go concurrency explanation demo

## Build
clang -O2 -target bpf -c xdp_drop_port.c -o xdp_drop_port.o

## Run
sudo python3 bpf_loader.py
