# Explanation

## Problem 1
XDP program drops TCP packets on port 4040 using eBPF map config.

## Problem 2
cgroup hook filters based on process name and port.

## Problem 3
Go worker pool using channels and goroutines.
