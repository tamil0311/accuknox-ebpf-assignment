
#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>

char TARGET_COMM[16] = \"myprocess\";

SEC(\"cgroup/connect4\")
int filter_process(struct bpf_sock_addr *ctx)
{
    char comm[16];
    bpf_get_current_comm(&comm, sizeof(comm));

    for (int i = 0; i < 16; i++) {
        if (comm[i] != TARGET_COMM[i])
            return 1;
    }

    if (ctx->user_port != 4040)
        return 0;

    return 1;
}

char _license[] SEC(\"license\") = \"GPL\";
