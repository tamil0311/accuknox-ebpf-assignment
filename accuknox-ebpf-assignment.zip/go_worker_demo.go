package main

import (
    "fmt"
    "sync"
)

func main() {
    cnp := make(chan func(), 10)
    var wg sync.WaitGroup

    for i := 0; i < 4; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            for f := range cnp {
                f()
            }
        }()
    }

    cnp <- func() {
        fmt.Println("HERE1")
    }

    fmt.Println("Hello")

    close(cnp)
    wg.Wait()
}
