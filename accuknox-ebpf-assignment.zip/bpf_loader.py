from bcc import BPF
import socket
import time

bpf = BPF(src_file="xdp_drop_port.c")
fn = bpf.load_func("xdp_drop_port", BPF.XDP)

iface = "eth0"
bpf.attach_xdp(iface, fn, 0)

port_map = bpf["port_map"]
port_map[0] = socket.htons(4040)

print("Running XDP drop on port 4040")

try:
    while True:
        time.sleep(2)
except KeyboardInterrupt:
    bpf.remove_xdp(iface, 0)
